package com;

public class LoginBean {
	private String lmt,password,device_id;
	
	public String getLmt() {
		return lmt;
	} 
	public void setLmt(String lmt) {  
	    this.lmt = lmt;  
	}
	
	public String getPassword() {  
	    return password;  
	}  
	  
	public void setPassword(String password) {  
	    this.password = password;  
	}
	public String getDevice_id() {
		
		return device_id;
	}
	public void setDevice_id(String device_id) {  
	    this.device_id = device_id;  
	}
	
}
