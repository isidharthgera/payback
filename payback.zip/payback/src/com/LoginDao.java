package com;

import java.sql.Connection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

import bean.ConnectionProvider;
import com.LoginBean;
public class LoginDao {

	public static boolean validate(LoginBean bean){  
		boolean status=false;  
		try{  
		Connection con=ConnectionProvider.getCon();  
		              
		PreparedStatement ps=con.prepareStatement(  
		    "SELECT * FROM device a,merchant b WHERE b.lmt=? AND b.password=? AND a.device_id=? AND a.merchant_id = b.lmt");  
		
		  
		ps.setString(1, bean.getLmt());  
		ps.setString(2, bean.getPassword());
		ps.setString(3, bean.getDevice_id());
		
		              
		ResultSet rs=ps.executeQuery();  
		status=rs.next();  
		              
		}catch(Exception e){}  
		  
		return status;  
		  
		} 

}
