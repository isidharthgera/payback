package com;

public interface Provider {
	String DRIVER="com.mysql.jdbc.Driver";  
	String CONNECTION_URL="jdbc:mysql://127.0.0.1:3306/payback_merchant";  
	String USERNAME="root";  
	String PASSWORD="enterpass"; 
}
