package device.bean;

public class Device {

	private int id;  
	private String merchant_id,device_id;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
	public String getMerchant_id() {
		// TODO Auto-generated method stub
		return merchant_id;
	}
	public void setMerchant_id(String merchant_id) {  
	    this.merchant_id = merchant_id;
	}

	public String getDevice_id() {
		// TODO Auto-generated method stub
		return device_id;
	}
	public void setDevice_id(String device_id) {  
	    this.device_id = device_id;
	}

}
