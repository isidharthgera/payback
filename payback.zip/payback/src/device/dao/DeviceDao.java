package device.dao;
import java.sql.*;  
import java.util.ArrayList;  
import java.util.List;  
import device.bean.Device;
import merchant.bean.Merchant;

public class DeviceDao {

	public static Connection getConnection(){  
	    Connection con=null;  
	    try{  
	        Class.forName("com.mysql.jdbc.Driver");  
	        con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/payback_merchant","root","enterpass");  
	    }catch(Exception e){System.out.println(e);}  
	    return con;  
	}  
	
	//add device
	
	public static int save(Device d){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement(  
	"insert into device(merchant_id,device_id) values(?,?)");  
	        ps.setString(1,d.getMerchant_id());  
	        ps.setString(2,d.getDevice_id());  
	       
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	    return status;  
	}  
	
	//get device by merchant id
	
	public static List<Device> getRecordsById(int id){  
	    List<Device> list=new ArrayList<Device>();  
	      
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("select * from device where merchant_id=?");  
	        ps.setInt(1,id); 
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next()){  
	            Device d=new Device();  
	            
	            d.setId(rs.getInt("id"));  
	            d.setMerchant_id(rs.getString("merchant_id"));  
	            d.setDevice_id(rs.getString("device_id")); 
	                         
	            list.add(d);  
	        }  
	    }catch(Exception e){System.out.println(e);}  
	    return list;  
	}
	
	//delete device
	
	public static int delete(Device d){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("delete from device where id=?");  
	        ps.setInt(1,d.getId());  
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	  
	    return status;  
	}  
	
	//view device by device id
	
	public static Device getRecordById(int id){  
	    Device d=null;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("select * from device where id=?");  
	        ps.setInt(1,id);  
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next()){  
	            d=new Device();  
	            d.setId(rs.getInt("id")); 
	            d.setMerchant_id(rs.getString("merchant_id"));
	            d.setDevice_id(rs.getString("device_id"));  
	           
	             
	        }  
	    }catch(Exception e){System.out.println(e);}  
	    return d;  
	}
	
	//update device by id
	public static int update(Device d){  
	    int status=0; 
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("update device set merchant_id=?,device_id=? where id=?");  
	        ps.setString(1,d.getMerchant_id());  
	        ps.setString(2,d.getDevice_id());  
	        ps.setInt(3,d.getId());  
	       status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	    return status;  
	}
	
}
