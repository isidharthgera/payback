package merchant.dao;
import java.sql.*;  
import java.util.ArrayList;  
import java.util.List;  
import merchant.bean.Merchant;  

public class MerchantDao {

	public static Connection getConnection(){  
	    Connection con=null;  
	    try{  
	        Class.forName("com.mysql.jdbc.Driver");  
	        con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/payback_merchant","root","enterpass");  
	    }catch(Exception e){System.out.println(e);}  
	    return con;  
	}  
	
	//Add Merchants
	public static int save(Merchant m){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("insert into merchant(name,lmt,password,address,phone,email) values(?,?,?,?,?,?)");  
	        ps.setString(1,m.getName());
	        ps.setString(2,m.getLmt());
	        ps.setString(3,m.getPassword());  
	        ps.setString(4,m.getAddress());  
	        ps.setString(5,m.getPhone());  
	        ps.setString(6,m.getEmail());  
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	    return status;  
	}  
	
	//View Merchants
	
	public static List<Merchant> getAllRecords(){  
	    List<Merchant> list=new ArrayList<Merchant>();  
	      
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("select * from merchant");  
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next()){  
	        	Merchant m=new Merchant();  
	            m.setId(rs.getInt("id"));  
	            m.setName(rs.getString("name"));
	            m.setLmt(rs.getString("lmt"));
	            m.setAddress(rs.getString("address"));  
	            m.setPhone(rs.getString("phone"));	            
	            m.setEmail(rs.getString("email"));  
	            
	            list.add(m);  
	        }  
	    }catch(Exception e){System.out.println(e);}  
	    return list;  
	}
	
	//get merchant by id
	
	public static Merchant getRecordById(int id){  
	    Merchant m=null;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("select * from merchant where id=?");  
	        ps.setInt(1,id);  
	        ResultSet rs=ps.executeQuery();  
	        while(rs.next()){  
	            m=new Merchant();  
	            m.setId(rs.getInt("id"));  
	            m.setName(rs.getString("name"));  
	            m.setLmt(rs.getString("lmt"));  
	            m.setPassword(rs.getString("password")); 
	            m.setAddress(rs.getString("address"));
	            m.setPhone(rs.getString("phone"));
	            m.setEmail(rs.getString("email"));  
	              
	        }  
	    }catch(Exception e){System.out.println(e);}  
	    return m;  
	}  
	
	//update merchant
	
	public static int update(Merchant m){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("update merchant set name=?,lmt=?,password=?,address=?,phone=?,email=? where id=?");  
	        ps.setString(1,m.getName());  
	        ps.setString(2,m.getLmt());
	        ps.setString(3,m.getPassword());
	        ps.setString(4,m.getAddress());
	        ps.setString(5,m.getPhone());
	        ps.setString(6,m.getEmail());  
	        ps.setInt(7,m.getId());  
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	    return status;  
	}  
	
	//delete merchant
	
	public static int delete(Merchant m){  
	    int status=0;  
	    try{  
	        Connection con=getConnection();  
	        PreparedStatement ps=con.prepareStatement("delete from merchant where id=?");  
	        ps.setInt(1,m.getId());  
	        status=ps.executeUpdate();  
	    }catch(Exception e){System.out.println(e);}  
	  
	    return status;  
	}  
}
